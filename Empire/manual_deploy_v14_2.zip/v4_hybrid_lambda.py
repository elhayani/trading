"""
Empire Trading System V13.2 - 11 ACTIFS BINANCE VALIDATED
=========================================================
Pump/News: DOGE (30min) - Momentum pur, news-driven
Tech L1: AVAX (30min) - Volatilité "High Tech"
Oracle: LINK (30min) - Décorrélation (matière première crypto)
Leaders: BTC, ETH, SOL, XRP, BNB (30min) - Noyau dur
RWA: PAXG (90min) - Or/Commodity
Indices: SPX (45min) - S&P 500
Parking: USDC (60min) - Trésorerie (Priorité Basse)

GSI Query for Positions (Critique #V11.5.1)
Smart OHLCV Caching (Critique #V11.5.2)
CCXT Singleton & Warm Cache (Critique #V11.5.3)
Circuit Breaker Yahoo (Critique #V11.5.4)
"""

import json
import os
import logging
import uuid
import time
from datetime import datetime, timezone, timedelta
from decimal import Decimal
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

import boto3
from botocore.exceptions import ClientError
import pandas as pd

# Absolute imports
import models
from models import MarketRegime, AssetClass
import config
from config import TradingConfig
import concurrent.futures
import market_analysis
from market_analysis import analyze_market, classify_asset, calculate_rsi
import news_fetcher
from news_fetcher import NewsFetcher
import exchange_connector
from exchange_connector import ExchangeConnector
import risk_manager
from risk_manager import RiskManager
import decision_engine
from decision_engine import DecisionEngine
import macro_context
from atomic_persistence import AtomicPersistence
from anti_spam_helpers import is_in_cooldown, record_trade_timestamp, get_real_binance_positions
from trim_switch import evaluate_trim_and_switch

@dataclass
class MacroContext:
    can_trade: bool = True
    confidence_score: float = 1.0
    regime: str = "NORMAL"

def to_decimal(obj):
    if isinstance(obj, float): return Decimal(str(obj))
    if isinstance(obj, Enum): return obj.value
    if isinstance(obj, dict): return {k: to_decimal(v) for k, v in obj.items()}
    if isinstance(obj, list): return [to_decimal(v) for v in obj]
    return obj

def from_decimal(obj):
    if isinstance(obj, Decimal): return float(obj)
    if isinstance(obj, dict): return {k: from_decimal(v) for k, v in obj.items()}
    if isinstance(obj, list): return [from_decimal(v) for v in obj]
    return obj

# ==================== LOGGING ====================

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

# ==================== AWS ====================

class AWSClients:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized: return
        self.region = os.getenv('AWS_REGION', 'us-east-1')
        self.dynamodb = boto3.resource('dynamodb', region_name=self.region)
        self.secretsmanager = boto3.client('secretsmanager', region_name=self.region)
        self.trades_table = self.dynamodb.Table(os.getenv('HISTORY_TABLE', 'EmpireTradesHistory'))
        self.skipped_table = self.dynamodb.Table(os.getenv('SKIPPED_TABLE', 'EmpireSkippedTrades'))
        self.state_table = self.dynamodb.Table(os.getenv('STATE_TABLE', 'V4TradingState'))
        self._initialized = True

class PersistenceLayer:
    def __init__(self, aws: AWSClients):
        self.aws = aws
    
    def log_trade_open(self, trade_id, symbol, asset_class, direction, entry_price, size, cost, tp_price, sl_price, leverage, reason=None, is_test=False):
        try:
            timestamp = datetime.now(timezone.utc).isoformat()
            item = {
                'trader_id': trade_id,
                'timestamp': timestamp,
                'TradeId': trade_id,
                'Symbol': symbol,
                'Pair': symbol,
                'AssetClass': asset_class,
                'Type': direction,
                'EntryPrice': entry_price,
                'Size': size,
                'Cost': cost,
                'TakeProfit': tp_price,
                'StopLoss': sl_price,
                'Leverage': leverage,
                'Timestamp': timestamp,
                'Status': 'OPEN',
                'is_test': is_test
            }
            if reason:
                item['Reason'] = reason
            
            self.aws.trades_table.put_item(Item=to_decimal(item))
            logger.info(f"[DB] OPEN logged: {symbol} {direction} x{leverage} {'(TEST)' if is_test else ''} | Entry=${entry_price:.4f} | TP=${tp_price:.4f} | SL=${sl_price:.4f}")
        except Exception as e: logger.error(f"[ERROR] Failed to log trade: {e}")
    
    def log_trade_close(self, trade_id, exit_price, pnl, reason, is_test=False):
        try:
            # Query by partition key (trader_id = trade_id) - O(1) instead of full table scan
            response = self.aws.trades_table.query(
                KeyConditionExpression='trader_id = :tid',
                ExpressionAttributeValues={':tid': trade_id},
                Limit=1
            )
            
            if response.get('Items'):
                item = response['Items'][0]
                trader_id = item['trader_id']
                timestamp = item['timestamp']
                
                self.aws.trades_table.update_item(
                    Key={'trader_id': trader_id, 'timestamp': timestamp},
                    UpdateExpression='SET #st = :status, ExitPrice = :price, PnL = :pnl, ExitReason = :reason, ClosedAt = :closed_at, is_test = :is_test',
                    ExpressionAttributeNames={'#st': 'Status'},
                    ExpressionAttributeValues=to_decimal({
                        ':status': 'CLOSED', ':price': exit_price, ':pnl': pnl, ':reason': reason,
                        ':closed_at': datetime.now(timezone.utc).isoformat(),
                        ':is_test': is_test
                    })
                )
                logger.info(f"[INFO] Logged CLOSE for {trade_id}: PnL={pnl}, Reason={reason} {'(TEST)' if is_test else ''}")
            else:
                logger.warning(f"[WARN] Trade {trade_id} not found for close update")
        except Exception as e: 
            logger.error(f"[ERROR] Failed to log close: {e}")

    def log_skipped_trade(self, symbol, reason, asset_class, is_test=False):
        try:
            trade_id = f"SKIP-{uuid.uuid4().hex[:8]}"
            timestamp = datetime.now(timezone.utc).isoformat()
            # TTL: auto-delete after 7 days (epoch seconds)
            ttl = int((datetime.now(timezone.utc) + timedelta(days=7)).timestamp())
            self.aws.skipped_table.put_item(Item=to_decimal({
                'trader_id': trade_id,
                'timestamp': timestamp,
                'Symbol': symbol,
                'Pair': symbol,
                'AssetClass': asset_class,
                'Status': 'SKIPPED',
                'Reason': reason,
                'ttl': ttl,
                'is_test': is_test
            }))
            logger.info(f"[INFO] Logged SKIP for {symbol}: {reason} {'(TEST)' if is_test else ''}")
        except Exception as e: 
            logger.error(f"[ERROR] Failed to log skip: {e}")
    
    def save_position(self, symbol, position_data, is_test=False):
        try:
            # Sanitize symbol for DynamoDB keys
            safe_symbol = symbol.replace('/', '_').replace(':', '-')
            # We add a 'status' field for GSI (Audit #V11.5)
            position_data['status'] = 'OPEN'
            position_data['is_test'] = is_test
            self.aws.state_table.put_item(Item=to_decimal({
                'trader_id': f'POSITION#{safe_symbol}', 
                'position': position_data,
                'status': 'OPEN',
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'is_test': is_test
            }))
        except Exception as e: logger.error(f"[ERROR] Failed to save position: {e}")
    
    def load_positions(self):
        """
        GSI Optimized Query (Critique #V11.5.1)
        Gain: 500ms -> 18ms
        """
        try:
            response = self.aws.state_table.query(
                IndexName='status-timestamp-index',
                KeyConditionExpression='#status = :open',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={':open': 'OPEN'}
            )
            # Convert back from sanitized to original symbols for compatibility
            positions = {}
            for item in response.get('Items', []):
                sanitized_symbol = item['trader_id'].replace('POSITION#', '')
                # Convert back: _ -> / and - -> :
                original_symbol = sanitized_symbol.replace('_', '/').replace('-', ':')
                positions[original_symbol] = from_decimal(item['position'])
            return positions
        except Exception as e:
            # Fallback to scan if GSI is not yet ready or fails
            logger.warning(f"[WARN] GSI Query failed, falling back to scan: {e}")
            try:
                response = self.aws.state_table.scan(
                    FilterExpression='begins_with(trader_id, :prefix)',
                    ExpressionAttributeValues={':prefix': 'POSITION#'}
                )
                # Convert back from sanitized to original symbols
                positions = {}
                for item in response.get('Items', []):
                    sanitized_symbol = item['trader_id'].replace('POSITION#', '')
                    original_symbol = sanitized_symbol.replace('_', '/').replace('-', ':')
                    positions[original_symbol] = from_decimal(item['position'])
                return positions
            except Exception as e2:
                logger.error(f"[ERROR] Failed to load positions (Scan): {e2}")
                return {}
    
    def save_risk_state(self, state):
        try:
            self.aws.state_table.put_item(Item=to_decimal({
                'trader_id': 'RISK_MANAGER#GLOBAL', 'state': state,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }))
        except Exception as e: logger.error(f"[ERROR] Failed to save risk state: {e}")

    def load_risk_state(self):
        try:
            response = self.aws.state_table.get_item(Key={'trader_id': 'RISK_MANAGER#GLOBAL'})
            return from_decimal(response.get('Item', {}).get('state', {}))
        except Exception as e:
            logger.error(f"[ERROR] Failed to load risk state: {e}")
            return {}

    def delete_position(self, symbol):
        try: 
            # Sanitize symbol for DynamoDB keys
            safe_symbol = symbol.replace('/', '_').replace(':', '-')
            # We don't delete, we update status for GSI management or delete item
            self.aws.state_table.delete_item(Key={'trader_id': f'POSITION#{safe_symbol}'})
        except Exception as e: logger.error(f"[ERROR] Failed to delete position: {e}")

    def get_history_context(self) -> Dict:
        """
        🏛️ EMPIRE V13.6: Memory of 20 Events
        Fetches 10 last skipped trades and 10 last history trades.
        Returns only: asset, time, reason, status.
        """
        try:
            # 1. Fetch last 10 skipped (exclude is_test=True)
            skipped_resp = self.aws.skipped_table.scan(Limit=50, FilterExpression='attribute_not_exists(is_test) OR is_test = :f', ExpressionAttributeValues={':f': False})
            skipped_raw = sorted(skipped_resp.get('Items', []), key=lambda x: x.get('timestamp', ''), reverse=True)[:10]
            
            skipped = []
            for s in skipped_raw:
                skipped.append({
                    'asset': s.get('Symbol') or s.get('Pair'),
                    'time': s.get('timestamp'),
                    'reason': s.get('Reason'),
                    'status': 'SKIPPED'
                })

            # 2. Fetch last 10 history (Open/Closed) (exclude is_test=True)
            history_resp = self.aws.trades_table.scan(Limit=50, FilterExpression='attribute_not_exists(is_test) OR is_test = :f', ExpressionAttributeValues={':f': False})
            history_raw = sorted(history_resp.get('Items', []), key=lambda x: x.get('timestamp', ''), reverse=True)[:10]
            
            history = []
            for h in history_raw:
                status = h.get('Status', 'UNKNOWN').upper()
                reason = h.get('ExitReason') if status == 'CLOSED' else h.get('Reason')
                history.append({
                    'asset': h.get('Symbol') or h.get('Pair'),
                    'time': h.get('timestamp') or h.get('Timestamp'),
                    'reason': reason,
                    'status': status
                })
            
            return {
                'skipped': from_decimal(skipped),
                'history': from_decimal(history)
            }
        except Exception as e:
            logger.error(f"[ERROR] Failed to fetch history context: {e}")
            return {'skipped': [], 'history': []}

# ==================== ENGINE ====================

class TradingEngine:
    def __init__(self, execution_id: str = None):
        self.execution_id = execution_id or f"EXEC-{uuid.uuid4().hex[:6]}"
        self.aws = AWSClients()
        self.persistence = PersistenceLayer(self.aws)
        self.atomic_persistence = AtomicPersistence(self.aws.state_table)
        self.ohlcv_cache_path = '/tmp/ohlcv_cache.json'
        self.cooldown_seconds = 300  # Anti-spam: 5 minutes cooldown per symbol
        
        mode = os.getenv('TRADING_MODE', 'dry_run')
        credentials = {}
        secret_name = os.getenv('SECRET_NAME')
        if secret_name:
            try:
                response = self.aws.secretsmanager.get_secret_value(SecretId=secret_name)
                credentials = json.loads(response['SecretString'])
            except Exception as e:
                logger.error(f"[ERROR] Secret fetch failed: {e}")
                if mode == 'live': raise
        
        # Robust Credential Extraction
        api_key = credentials.get('api_key') or credentials.get('apiKey') or credentials.get('API_KEY')
        secret = credentials.get('secret') or credentials.get('secretKey') or credentials.get('SECRET_KEY') or credentials.get('api_secret')
        
        if api_key: api_key = api_key.strip()
        if secret: secret = secret.strip()

        # Optimized Connector (Singleton/Warm)
        # Fix -2008: Clear separation between Live and Demo (Audit #V11.6.6)
        is_live = TradingConfig.LIVE_MODE
        logger.info(f"[BOOT] Mode ACTIVE: {'LIVE (REAL TRADING)' if is_live else 'DEMO (MOCK TRADING)'}")
        
        self.exchange = ExchangeConnector(
            api_key=api_key,
            secret=secret,
            live_mode=is_live
        )
        
        self.risk_manager = RiskManager()
        self.decision_engine = DecisionEngine(risk_manager=self.risk_manager)
        self.news_fetcher = NewsFetcher()
        
        # Hydrate RiskManager
        self.risk_manager.load_state(self.persistence.load_risk_state())
        logger.info(f"[INFO] TradingEngine V11.5 initialized [{mode.upper()}]")

    def _get_ohlcv_smart(self, symbol: str, timeframe='1h') -> List:
        """
        Smart Strategy:
        1. Load local cache (/tmp)
        2. Fetch only new candles (limit=10)
        3. Merge and save
        (Critique #V11.5.2) -82% latency
        """
        cache = self._load_ohlcv_cache()
        cached_data = cache.get(symbol, [])
        
        if cached_data:
            try:
                # Fetch only latest few candles (Audit #V11.5)
                latest = self.exchange.fetch_ohlcv(symbol, timeframe, limit=10)
                
                # Merge without duplicates
                last_cached_ts = cached_data[-1][0]
                new_candles = [c for c in latest if c[0] > last_cached_ts]
                
                merged = cached_data + new_candles
                merged = merged[-500:] # Keep last 500
                
                if new_candles:
                    logger.info(f"[CACHE HIT] {symbol}: {len(new_candles)} new candles added")
                else:
                    logger.info(f"[CACHE HIT] {symbol}: Already up to date")
            except Exception as e:
                logger.warning(f"[WARN] Smart OHLCV fetch failed: {e}. Falling back to full fetch.")
                merged = self.exchange.fetch_ohlcv(symbol, timeframe, limit=500)
        else:
            # First time: full fetch
            merged = self.exchange.fetch_ohlcv(symbol, timeframe, limit=500)
            logger.info(f"[CACHE MISS] {symbol}: fetched 500 candles")
            
        # Update cache
        cache[symbol] = merged
        self._save_ohlcv_cache(cache)
        return merged

    def _load_ohlcv_cache(self) -> Dict:
        try:
            if os.path.exists(self.ohlcv_cache_path):
                with open(self.ohlcv_cache_path, 'r') as f:
                    return json.load(f)
        except: pass
        return {}

    def _save_ohlcv_cache(self, cache: Dict):
        try:
            with open(self.ohlcv_cache_path, 'w') as f:
                json.dump(cache, f)
        except Exception as e: logger.warning(f"[WARN] Failed to save OHLCV cache: {e}")
    
    def run_cycle(self, symbol: str, btc_rsi: Optional[float] = None) -> Dict:
        # Resolve to canonical symbol early (Audit #V11.6.8)
        symbol = self.exchange.resolve_symbol(symbol)
        asset_class = classify_asset(symbol)  # Define early for logging
        
        logger.info(f"\n{'='*70}\n[INFO] CYCLE START: {symbol}\n{'='*70}")
        try:
            # EMPIRE V12.6: "NOUVELLE PAGE BLANCHE" - No cooldown timer
            # ANTI-SPAM via position detection only (not time-based)
            # This allows:
            # 1. AGNOSTICISME: LONG to SHORT switches without delay
            # 2. RE-ENTRY: Exit at 1% profit, re-scan, re-enter if signal still strong
            # 3. CAPITAL VELOCITY: Capture multiple 1% moves on same asset during trends
            # Philosophy: Don't marry a trade - force re-evaluation after each exit
            
            # Load positions and manage them (check SL/TP/exits)
            positions = self.persistence.load_positions()
            if positions: 
                self._manage_positions(positions)
                # Reload positions after management (some may have been closed)
                positions = self.persistence.load_positions()
            
            # CRITICAL: Check real Binance position before trusting DynamoDB
            real_positions = self._get_real_binance_positions()
            if symbol in real_positions:
                logger.warning(f"[REAL_POSITION] {symbol} already open on Binance (managed)")
                
                # CRITICAL FIX: Manage Binance positions even if not in DynamoDB
                if symbol not in positions:
                    # Create mock position from Binance data for management
                    mock_positions = self._create_mock_binance_position(symbol)
                    if mock_positions:
                        logger.info(f"[MOCK_POSITION] Managing Binance-only position: {symbol}")
                        self._manage_positions(mock_positions)
                
                self.persistence.log_skipped_trade(symbol, "Position already open on Binance", asset_class)
                return {'symbol': symbol, 'status': 'IN_POSITION_BINANCE'}
            
            if symbol in positions:
                logger.info(f"[INFO] Skip: Already in position for {symbol}")
                self.persistence.log_skipped_trade(symbol, "Position already in DynamoDB", asset_class)
                return {'symbol': symbol, 'status': 'IN_POSITION'}
            
            # EMPIRE V13.0: REPLACE_LOW_PRIORITY - Flash Exit for USDC/USDT parking position
            # If USDC/USDT (forex) is open and a high-priority opportunity appears, eject immediately
            usdc_position = positions.get('USDC/USDT:USDT')
            if usdc_position and usdc_position.get('asset_class') == 'forex':
                # Check if current symbol is high-priority (crypto or commodity) with strong signal
                if asset_class in ['crypto', 'commodities']:
                    # Get quick score for current symbol
                    ohlcv_quick = self._get_ohlcv_smart(symbol, '1h')
                    ta_quick = analyze_market(ohlcv_quick, symbol=symbol, asset_class=asset_class)
                    quick_score = ta_quick.get('score', 0)
                    
                    if quick_score > 85:  # High-priority opportunity detected
                        logger.warning(f"[FLASH_EXIT] Ejecting USDC parking position for {symbol} (score: {quick_score})")
                        try:
                            # Close USDC immediately (market order)
                            usdc_direction = usdc_position.get('direction', 'LONG')
                            usdc_side = 'sell' if usdc_direction == 'LONG' else 'buy'
                            usdc_qty = usdc_position.get('quantity', 0)
                            
                            exit_order = self.exchange.create_market_order('USDC/USDT:USDT', usdc_side, usdc_qty)
                            exit_price = float(exit_order.get('average', 0))
                            
                            # Calculate PnL
                            entry_price = float(usdc_position.get('entry_price', 0))
                            if usdc_direction == 'LONG':
                                pnl_pct = ((exit_price - entry_price) / entry_price) * 100
                            else:
                                pnl_pct = ((entry_price - exit_price) / entry_price) * 100
                            
                            pnl = self.risk_manager.close_trade('USDC/USDT:USDT', exit_price)
                            
                            reason = f"Flash Exit for priority {symbol} (score: {quick_score}, USDC PnL: {pnl_pct:+.2f}%)"
                            self.persistence.log_trade_close(usdc_position['trade_id'], exit_price, pnl, reason)
                            self.persistence.delete_position('USDC/USDT:USDT')
                            self.atomic_persistence.atomic_remove_risk('USDC/USDT:USDT', float(usdc_position.get('risk_dollars', 0)))
                            
                            del positions['USDC/USDT:USDT']
                            balance = self.exchange.get_balance_usdt()  # Refresh balance
                            
                            logger.info(f"[FLASH_EXIT] USDC closed, capital freed: ${balance:.0f}")
                        except Exception as e:
                            logger.error(f"[ERROR] Flash exit failed: {e}")
            
            # Get balance early (needed for trim check and later logic)
            balance = self.exchange.get_balance_usdt()
            if balance < 10: raise ValueError("Insufficient balance ( < $10 )")
            
            # TRIM & SWITCH: Check if we should reduce existing positions for better opportunities
            # Only if we have positions AND low available capital
            if positions and balance < 500:  # Less than $500 available
                logger.info(f"[TRIM_CHECK] Low capital (${balance:.0f}), checking for better opportunities...")
            
            # Smart OHLCV Fetching (Audit #V11.5)
            ohlcv = self._get_ohlcv_smart(symbol, '1h')
            ta_result = analyze_market(ohlcv, symbol=symbol, asset_class=asset_class)
            
            if ta_result.get('market_context', '').startswith('VOLATILITY_SPIKE'):
                reason = ta_result['market_context']
                self.persistence.log_skipped_trade(symbol, reason, asset_class)
                return {'symbol': symbol, 'status': 'BLOCKED', 'reason': reason}
            
            news_score = self.news_fetcher.get_news_sentiment_score(symbol)
            macro = macro_context.get_macro_context(state_table=self.aws.state_table)
            
            direction = 'SHORT' if ta_result.get('signal_type') == 'SHORT' else 'LONG'
            if ta_result.get('signal_type') == 'NEUTRAL':
                # Build meaningful skip reason
                rsi = ta_result.get('rsi', 50)
                score = ta_result.get('score', 0)
                
                # EMPIRE V13.2: USDC/USDT low-priority entry logic (10 actifs prioritaires)
                # Only enter USDC if it's forex AND all other priority assets are calm (<50 score)
                if asset_class == 'forex' and 'USDC' in symbol:
                    # Check if this is a calm market - scan priority assets (V13.2: 10 actifs)
                    priority_symbols = [
                        'BTC/USDT:USDT', 'ETH/USDT:USDT', 'SOL/USDT:USDT', 'XRP/USDT:USDT', 'BNB/USDT:USDT',  # Leaders (5)
                        'DOGE/USDT:USDT',  # Pump/News (1)
                        'AVAX/USDT:USDT',  # Tech L1 (1)
                        'LINK/USDT:USDT',  # Oracle (1)
                        'PAXG/USDT:USDT',  # RWA/Commodities (1)
                        'SPX/USDT:USDT'  # Indices (1)
                    ]
                    all_calm = True
                    
                    for priority_sym in priority_symbols:
                        if priority_sym in positions:
                            # Already have a priority position, don't enter USDC
                            all_calm = False
                            break
                        
                        try:
                            priority_ohlcv = self._get_ohlcv_smart(priority_sym, '1h')
                            priority_ta = analyze_market(priority_ohlcv, symbol=priority_sym, asset_class=classify_asset(priority_sym))
                            priority_score = priority_ta.get('score', 0)
                            
                            if priority_score >= 50:  # Priority asset has opportunity
                                all_calm = False
                                logger.info(f"[USDC_SKIP] {priority_sym} has score {priority_score} >= 50, skipping USDC parking")
                                break
                        except:
                            pass
                    
                    if not all_calm:
                        reason = "Priority assets active (score >= 50), USDC parking not needed"
                        self.persistence.log_skipped_trade(symbol, reason, asset_class)
                        return {'symbol': symbol, 'status': 'LOW_PRIORITY_BLOCKED', 'reason': reason}
                    else:
                        logger.info(f"[USDC_PARKING] All priority assets calm, allowing USDC entry as parking position")
                        # Continue to decision engine - USDC can enter as parking position
                else:
                    # Not USDC or not neutral - normal skip logic
                    reasons = []
                    if rsi > 70:
                        reasons.append(f"RSI > 70 (overbought: {rsi:.1f})")
                    elif rsi < 30:
                        reasons.append(f"RSI < 30 (oversold: {rsi:.1f})")
                    else:
                        reasons.append(f"RSI neutral ({rsi:.1f})")
                    
                    if score < 50:
                        # 🏛️ EMPIRE V14.2: Detailed AI Reasoning for Score Failure
                        rsi_val = ta_result['indicators']['rsi']
                        vol_ratio = ta_result['indicators']['vol_ratio']
                        context = ta_result.get('market_context', 'N/A')
                        reasons.append(f"Low Score ({score}/100) -> RSI:{rsi_val:.1f} (Neutral), Vol:{vol_ratio:.1f}x, Ctx:{context}")
                    
                    # Check volume if available
                    if 'volume_spike' in ta_result.get('market_context', ''):
                        reasons.append("Low volume")
                    
                    # Check trend
                    trend = ta_result.get('market_context', '')
                    if 'Trend=' in trend:
                        trend_val = trend.split('Trend=')[1].split('|')[0].strip()
                        if trend_val == 'SIDEWAYS':
                            reasons.append("Sideways trend")
                    
                    reason = " | ".join(reasons) if reasons else f"No clear signal (RSI={rsi:.1f})"
                    self.persistence.log_skipped_trade(symbol, reason, asset_class)
                    return {'symbol': symbol, 'status': 'NO_SIGNAL', 'score': ta_result.get('score')}

            # EMPIRE V13.6: Fetch Memory Context
            history_context = self.persistence.get_history_context()

            decision = self.decision_engine.evaluate_with_risk(
                context=macro, ta_result=ta_result, symbol=symbol,
                capital=balance, direction=direction, asset_class=asset_class,
                news_score=news_score, macro_regime=macro.get('regime', 'NORMAL'),
                btc_rsi=btc_rsi,
                history_context=history_context
            )
            
            if not decision['proceed']:
                logger.info(f"[INFO] Blocked: {decision['reason']}")
                self.persistence.log_skipped_trade(symbol, decision['reason'], asset_class)
                return {'symbol': symbol, 'status': 'BLOCKED', 'reason': decision['reason']}
            
            # MAX_OPEN_TRADES enforcement (V13.4 - prevent position overflow)
            real_positions = self._get_real_binance_positions()
            open_count = max(len(positions), len(real_positions))
            
            if open_count >= TradingConfig.MAX_OPEN_TRADES:
                # 🏛️ EMPIRE V13.5: Early Exit for Opportunity (75% / Score+)
                # Before skipping, check if we can free a slot by removing a stagnating trade
                if self._evaluate_early_exit_for_opportunity(positions, symbol, ta_result, decision):
                    # Successfully freed a slot!
                    open_count -= 1
                    logger.info(f"[EARLY_EXIT_SUCCESS] Slot freed for {symbol}")
                else:
                    reason = f"MAX_OPEN_TRADES reached ({open_count}/{TradingConfig.MAX_OPEN_TRADES})"
                    logger.warning(f"[SLOT_FULL] {reason}")
                    self.persistence.log_skipped_trade(symbol, reason, asset_class)
                    return {'symbol': symbol, 'status': 'SLOT_FULL', 'reason': reason}
            
            # TRIM & SWITCH: If we have a high-confidence signal but low capital, consider trimming positions
            if positions and balance < 500 and decision['confidence'] >= 0.75:
                trim_result = self._evaluate_trim_and_switch(positions, symbol, decision, balance)
                if trim_result['action'] == 'TRIMMED':
                    balance = trim_result['freed_capital']
                    logger.info(f"[TRIM_SUCCESS] Freed ${balance:.0f} for {symbol} opportunity")
            
            return self._execute_entry(symbol, direction, decision, ta_result, asset_class, balance)
            
        except Exception as e:
            logger.error(f"[ERROR] Cycle error: {e}")
            return {'symbol': symbol, 'status': 'ERROR', 'error': str(e)}
    
    def _execute_entry(self, symbol, direction, decision, ta_result, asset_class, balance):
        # BINANCE SYNC: Verify no existing position before opening (source of truth)
        binance_pos = self._get_binance_position_detail(symbol)
        if binance_pos:
            reason = f"BINANCE_SYNC: Position already exists on Binance ({binance_pos['side']} {binance_pos['quantity']} @ ${binance_pos['entry_price']:.2f})"
            logger.warning(f"[BINANCE_BLOCK] {symbol} — {reason}")
            self.persistence.log_skipped_trade(symbol, reason, asset_class)
            return {'symbol': symbol, 'status': 'BINANCE_ALREADY_OPEN', 'reason': reason}
        
        trade_id = f"V11-{uuid.uuid4().hex[:8]}"
        side = 'sell' if direction == 'SHORT' else 'buy'
        quantity = decision['quantity']
        
        market_info = self.exchange.get_market_info(symbol)
        min_amount = market_info.get('min_amount', 0)
        if quantity < min_amount: quantity = min_amount

        # PAXG-specific: leverage x4 for low-volatility gold token
        is_paxg = 'PAXG' in symbol
        leverage = TradingConfig.PAXG_LEVERAGE if is_paxg else TradingConfig.LEVERAGE
        
        try:
            order = self.exchange.create_market_order(symbol, side, quantity, leverage=leverage)
            real_entry = float(order.get('average', ta_result['price']))
            real_size = float(order.get('filled', quantity))
            
            # 🏛️ TACTICAL ALERT: Slippage Check
            theoretical_price = float(ta_result['price'])
            slippage_pct = abs((real_entry - theoretical_price) / theoretical_price) * 100
            
            if slippage_pct > 0.1:
                logger.warning(f"⚠️ [TACTICAL_ALERT] High Entry Slippage: {slippage_pct:.3f}% for {symbol}")
            else:
                logger.info(f"[OK] {direction} filled: {real_size} @ ${real_entry:.2f} (Slippage: {slippage_pct:.3f}%)")
                
        except Exception as e:
            logger.error(f"[ERROR] Order failed: {e}")
            return {'symbol': symbol, 'status': 'ORDER_FAILED', 'error': str(e)}
        
        success, reason = self.atomic_persistence.atomic_check_and_add_risk(
            symbol=symbol,
            risk_dollars=decision['risk_dollars'],
            capital=balance,
            entry_price=real_entry,
            quantity=real_size,
            direction=direction
        )
        
        if not success:
            logger.error(f"[ALERT] Atomic risk check failed: {reason}. Attempting order rollback...")
            try:
                rollback_side = 'sell' if direction == 'LONG' else 'buy'
                self.exchange.create_market_order(symbol, rollback_side, real_size, leverage=leverage)
                logger.info(f"[OK] Emergency rollback executed for {symbol}")
            except Exception as rollback_err:
                logger.error(f"[CRITICAL] ROLLBACK FAILED: {rollback_err}")
            self.persistence.log_skipped_trade(symbol, reason, asset_class)
            return {'symbol': symbol, 'status': 'BLOCKED_ATOMIC', 'reason': reason}
        
        # PAXG: TP 0.35% brut (~0.30% net) / SL 0.50% | Others: standard scalping config
        if is_paxg:
            tp_pct = TradingConfig.PAXG_TP
            sl_pct = TradingConfig.PAXG_SL
            logger.info(f"[PAXG] Gold mode: Leverage {leverage}x | TP {tp_pct*100:.2f}% brut (~0.30% net) | SL {sl_pct*100:.2f}%")
        else:
            tp_pct = TradingConfig.SCALP_TP_MIN + ((TradingConfig.SCALP_TP_MAX - TradingConfig.SCALP_TP_MIN) / 2)
            sl_pct = TradingConfig.SCALP_SL
        
        tp = real_entry * (1 + tp_pct) if direction == 'LONG' else real_entry * (1 - tp_pct)
        sl = real_entry * (1 - sl_pct) if direction == 'LONG' else real_entry * (1 + sl_pct)
        
        logger.info(f"[SCALP] Entry: ${real_entry:.4f} | TP: ${tp:.4f} ({tp_pct*100:.2f}%) | SL: ${sl:.4f} ({sl_pct*100:.2f}%)")
        
        # 🏛️ EMPIRE V13.9: Place GTC SL/TP orders immediately on Binance
        self.exchange.create_sl_tp_orders(symbol, side, real_size, sl, tp)
        
        # Build detailed reason with technical indicators
        reason_parts = []
        if 'rsi' in ta_result:
            reason_parts.append(f"RSI={ta_result['rsi']:.1f}")
        if ta_result.get('market_context'):
            reason_parts.append(ta_result['market_context'])
        if decision.get('confidence'):
            reason_parts.append(f"AI={decision['confidence']*100:.0f}%")
        if 'score' in ta_result:
            reason_parts.append(f"Score={ta_result['score']}")
        reason_parts.append(f"Lev={leverage}x")
        
        detailed_reason = " | ".join(reason_parts) if reason_parts else decision.get('reason', 'Signal detected')
        
        self.persistence.log_trade_open(
            trade_id, symbol, asset_class, direction, real_entry, real_size,
            (real_size * real_entry) / leverage, tp, sl, leverage,
            reason=detailed_reason
        )
        
        pos_data = {
            'trade_id': trade_id, 'entry_price': real_entry, 'quantity': real_size,
            'direction': direction, 'stop_loss': sl, 'take_profit': tp,
            'asset_class': asset_class,
            'risk_dollars': decision['risk_dollars'],
            'score': ta_result.get('score', 0),
            'ai_score': int(decision.get('confidence', 0) * 100),
            'entry_time': datetime.now(timezone.utc).isoformat()
        }
        self.persistence.save_position(symbol, pos_data)
        
        # Local state sync
        self.risk_manager.register_trade(symbol, real_entry, real_size, decision['risk_dollars'], decision['stop_loss'], direction)
        self.persistence.save_risk_state(self.risk_manager.get_state())
        
        # Record trade timestamp for cooldown
        self._record_trade_timestamp(symbol)
        
        logger.info(f"[OK] Position opened atomically: {direction} {symbol}")
        return {'symbol': symbol, 'status': f'{direction}_OPEN', 'trade_id': trade_id}
    
    def _is_in_cooldown(self, symbol: str) -> bool:
        """Check if symbol is in cooldown period (anti-spam protection)"""
        return is_in_cooldown(self.aws.state_table, symbol, self.cooldown_seconds)
    
    def _record_trade_timestamp(self, symbol: str):
        """Record trade timestamp for cooldown tracking"""
        record_trade_timestamp(self.aws.state_table, symbol)
    
    def _get_real_binance_positions(self) -> List[str]:
        """Get actual open positions from Binance (source of truth)"""
        return get_real_binance_positions(self.exchange)
    
    def _get_binance_position_detail(self, symbol: str) -> Optional[Dict]:
        """Get real position detail from Binance for a specific symbol. Returns None if no position."""
        try:
            ccxt_ex = self.exchange.exchange if hasattr(self.exchange, 'exchange') else self.exchange
            positions = ccxt_ex.fapiPrivateV2GetPositionRisk()
            # Convert symbol to Binance format (SOL/USDT:USDT -> SOLUSDT)
            binance_sym = symbol.replace('/USDT:USDT', 'USDT').replace('/', '')
            for pos in positions:
                if pos.get('symbol') == binance_sym:
                    qty = abs(float(pos.get('positionAmt', 0)))
                    if qty > 0:
                        return {
                            'quantity': qty,
                            'side': 'LONG' if float(pos['positionAmt']) > 0 else 'SHORT',
                            'entry_price': float(pos.get('entryPrice', 0)),
                            'unrealized_pnl': float(pos.get('unRealizedProfit', 0)),
                            'mark_price': float(pos.get('markPrice', 0)),
                            'leverage': int(pos.get('leverage', 1))
                        }
            return None
        except Exception as e:
            logger.error(f"[BINANCE_SYNC] Failed to get position detail for {symbol}: {e}")
            return None
    
    def _create_mock_binance_position(self, symbol: str) -> Dict:
        """Create mock position data for Binance-only positions to enable SL/TP management"""
        try:
            # Get real position data from Binance
            positions = self.exchange.fetch_positions([symbol])
            if not positions:
                return {}
            
            pos_data = positions[0]
            if float(pos_data.get('contracts', 0)) == 0:
                return {}
            
            # Calculate TP/SL based on current price (since we don't have original entry)
            current_price = float(pos_data['lastPrice'])
            side = pos_data['side'].lower()  # 'long' or 'short'
            
            # Estimate entry price (use current price as fallback - not ideal but functional)
            entry_price = current_price
            
            # Set TP/SL based on current price (emergency protection)
            if side == 'long':
                tp = current_price * (1 + TradingConfig.SCALP_TP_MIN)
                sl = current_price * (1 - TradingConfig.SCALP_SL)
            else:
                tp = current_price * (1 - TradingConfig.SCALP_TP_MIN)
                sl = current_price * (1 + TradingConfig.SCALP_SL)
            
            mock_position = {
                'direction': side.upper(),
                'entry_price': entry_price,
                'quantity': float(pos_data['contracts']),
                'stop_loss': sl,
                'take_profit': tp,
                'entry_time': datetime.now(timezone.utc).isoformat(),
                'trade_id': f'EMERGENCY-{symbol.replace("/", "")}',
                'asset_class': classify_asset(symbol)
            }
            
            logger.warning(f"[MOCK_CREATED] {symbol}: {side.upper()} {mock_position['quantity']} @ ${entry_price:.2f}")
            return {symbol: mock_position}
            
        except Exception as e:
            logger.error(f"[MOCK_ERROR] Failed to create mock position for {symbol}: {e}")
            return {}
    
    def _evaluate_trim_and_switch(self, positions: Dict, new_symbol: str, new_decision: Dict, current_balance: float) -> Dict:
        """Evaluate if we should trim existing positions for better opportunities"""
        return evaluate_trim_and_switch(
            self.exchange,
            self.persistence,
            positions,
            new_symbol,
            new_decision,
            current_balance
        )

    def _evaluate_early_exit_for_opportunity(self, positions: Dict, new_symbol: str, new_ta: Dict, new_decision: Dict) -> bool:
        """
        🏛️ EMPIRE RULE: "Early Exit for Opportunity" (75% / Score+)
        Allows closing a stagnating trade to free a slot for a much better one.
        """
        new_score = new_ta.get('score', 0)
        new_ai_score = int(new_decision.get('confidence', 0) * 100)
        
        candidates = []
        for symbol, pos in positions.items():
            try:
                # 1. Check Stagnation (PnL entre -0,15% et +0,15%)
                ticker = self.exchange.fetch_ticker(symbol)
                current_price = float(ticker['last'])
                entry_price = float(pos.get('entry_price', 0))
                direction = pos['direction']
                
                if direction == 'LONG':
                    pnl_pct = ((current_price - entry_price) / entry_price) * 100
                else:
                    pnl_pct = ((entry_price - current_price) / entry_price) * 100
                
                if not (-0.15 <= pnl_pct <= 0.15):
                    continue
                
                # 2. Check Time Threshold (75% du MAX_TIME_EXIT)
                entry_time_str = pos.get('entry_time')
                if not entry_time_str: continue
                
                entry_time = datetime.fromisoformat(entry_time_str.replace('Z', '+00:00'))
                time_open_min = (datetime.now(timezone.utc) - entry_time).total_seconds() / 60
                
                asset_class = pos.get('asset_class', 'crypto')
                threshold_map = {
                    'crypto': 20,
                    'indices': 30,
                    'commodities': 90,
                    'forex': 60
                }
                max_time = threshold_map.get(asset_class, 60)
                time_trigger = max_time * 0.75
                
                if time_open_min < time_trigger:
                    continue
                
                # 3. Check Score Delta (+10 points)
                old_score = pos.get('score', 0)
                old_ai_score = pos.get('ai_score', 0)
                
                score_better = (new_score >= old_score + 10)
                ai_better = (new_ai_score >= old_ai_score + 10)
                
                if score_better or ai_better:
                    candidates.append({
                        'symbol': symbol,
                        'pnl_pct': pnl_pct,
                        'time_open': time_open_min,
                        'delta_score': new_score - old_score,
                        'delta_ai': new_ai_score - old_ai_score,
                        'pos_data': pos
                    })
            except Exception as e:
                logger.error(f"[EARLY_EXIT_ERR] Failed to evaluate {symbol}: {e}")
                continue
        
        if not candidates:
            return False
            
        candidates.sort(key=lambda x: x['time_open'], reverse=True)
        winner = candidates[0]
        
        reason = f"EARLY_EXIT for {new_symbol}: {winner['symbol']} stagnating ({winner['time_open']:.0f}m, {winner['pnl_pct']:+.2f}%)"
        logger.warning(f"🏛️ [EARLY_EXIT] {reason} | Score+{winner['delta_score']}, AI+{winner['delta_ai']}")
        
        return self._close_position(winner['symbol'], winner['pos_data'], reason)

    def _close_position(self, symbol: str, pos: Dict, reason: str) -> bool:
        """Unifie la logique de fermeture de position Binance + DynamoDB"""
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            current_price = float(ticker['last'])
            
            binance_detail = self._get_binance_position_detail(symbol)
            if not binance_detail:
                logger.error(f"[CLOSE_ERR] No position found on Binance for {symbol}")
                self.persistence.delete_position(symbol)
                return False
                
            real_qty = binance_detail['quantity']
            direction = pos['direction']
            exit_side = 'sell' if direction == 'LONG' else 'buy'
            
            exit_order = self.exchange.create_market_order(symbol, exit_side, real_qty)
            exit_price = float(exit_order.get('average', current_price))
            
            self.atomic_persistence.atomic_remove_risk(symbol, float(pos.get('risk_dollars', 0)))
            pnl = self.risk_manager.close_trade(symbol, exit_price)
            self.persistence.save_risk_state(self.risk_manager.get_state())
            self.persistence.log_trade_close(pos['trade_id'], exit_price, pnl, reason, is_test=pos.get('is_test', False))
            self.persistence.delete_position(symbol)
            
            # 🏛️ EMPIRE V13.9: Cleanup GTC orders
            self.exchange.cancel_all_orders(symbol)
            
            logger.info(f"[OK] Closed {symbol} | PnL: ${pnl:.2f}")
            return True
        except Exception as e:
            logger.error(f"[CLOSE_FAILED] {symbol}: {e}")
            return False
    
    def _manage_positions(self, positions: Dict):
        logger.info(f"\n{'='*70}\n[INFO] POSITION MANAGEMENT\n{'='*70}")
        for symbol, pos in list(positions.items()):
            try:
                ticker = self.exchange.fetch_ticker(symbol)
                if not ticker:
                    logger.warning(f"[MANAGE] Could not fetch ticker for {symbol}")
                    continue

                # 🏛️ EMPIRE V14.2: Robust Price Fetching (Fix float(NoneType) error)
                # Prioritize Mark Price, then Last Price, then Info values
                raw_price = ticker.get('markPrice')
                if raw_price is None:
                    raw_price = ticker.get('last')
                if raw_price is None and 'info' in ticker:
                    # Fallback to provider-specific info field
                    raw_price = ticker['info'].get('markPrice', ticker['info'].get('lastPrice'))
                
                if raw_price is None:
                    logger.warning(f"[MANAGE] No valid price found for {symbol}. Skipping.")
                    continue
                    
                current_price = float(raw_price)
                
                # Safe Entry Price
                entry_val = pos.get('entry_price')
                if entry_val is None:
                    logger.warning(f"[MANAGE] Missing entry_price for {symbol}")
                    continue
                entry_price = float(entry_val)
                if entry_price == 0: continue 

                direction = pos.get('direction', 'LONG')
                
                # Calculate current PnL %
                if direction == 'LONG':
                    pnl_pct = ((current_price - entry_price) / entry_price) * 100
                else:
                    pnl_pct = ((entry_price - current_price) / entry_price) * 100
                
                # Check traditional TP/SL - Safe Conversion
                sl_val = pos.get('stop_loss')
                tp_val = pos.get('take_profit')
                
                stop_loss = float(sl_val) if sl_val is not None else 0.0
                take_profit = float(tp_val) if tp_val is not None else 0.0
                
                # Only check SL/TP if they are set (non-zero)
                hit_sl = False
                hit_tp = False
                if stop_loss > 0:
                    hit_sl = (current_price <= stop_loss) if direction == 'LONG' else (current_price >= stop_loss)
                if take_profit > 0:
                    hit_tp = (current_price >= take_profit) if direction == 'LONG' else (current_price <= take_profit)
                
                # EMPIRE V14.2: Dynamic Sniper Profit (Uses Config 0.40%)
                threshold_pct = TradingConfig.SCALP_TP_MIN * 100
                hit_profit_sniper = pnl_pct >= threshold_pct
                if hit_profit_sniper:
                    logger.info(f"🏛️ [SNIPER_PROFIT] {symbol} reached +{pnl_pct:.2f}% (Target: {threshold_pct:.2f}%) - securing profit!")
                
                # EMPIRE V12.3: Time-based exits
                entry_time_str = pos.get('entry_time', '')
                should_exit_time = False
                should_exit_fast_discard = False
                
                if entry_time_str:
                    try:
                        entry_time = datetime.fromisoformat(entry_time_str.replace('Z', '+00:00'))
                        time_open_hours = (datetime.now(timezone.utc) - entry_time).total_seconds() / 3600
                        time_open_minutes = time_open_hours * 60
                        
                        # TIME_BASED_EXIT: Adaptatif par asset class (V13.4 - Levier x2/x4)
                        # Crypto (x2): 20min - Scalping rapide, momentum pur
                        # Indices (x2): 30min - Suivi de tendance
                        # Commodities/PAXG (x4): 90min - Rebond structurel, or lent
                        # Forex/Parking (x2): 60min - Stabilité
                        asset_class = pos.get('asset_class', 'crypto')
                        symbol_key = symbol if isinstance(symbol, str) else pos.get('symbol', '')
                        
                        # Crypto: 20min (x2 = scalping rapide)
                        if asset_class == 'crypto':
                            time_threshold_hours = 1/3  # 20min
                        # Indices: 30min (x2 = suivi tendance)
                        elif asset_class == 'indices':
                            time_threshold_hours = 0.5  # 30min
                        # Commodities (PAXG x4): 90min (or = rebond structurel)
                        elif asset_class == 'commodities' or 'PAXG' in symbol_key:
                            time_threshold_hours = 1.5  # 90min
                        # Forex (USDC): 60min (parking)
                        else:  # forex
                            time_threshold_hours = 1.0  # 60min
                        
                        if time_open_hours > time_threshold_hours:
                            should_exit_time = True
                            logger.warning(f"[TIME_EXIT] {symbol} ({asset_class}) open {time_open_hours*60:.0f}min - auto-close (PnL: {pnl_pct:+.2f}%)")
                        
                        # 🏛️ EMPIRE V13.7: FAST DISCARD (Momentum Required)
                        # If after 10 minutes, PnL is stagnant near zero (-0.05% to +0.05%), release the slot.
                        if time_open_minutes >= 10 and -0.05 <= pnl_pct <= 0.05:
                            should_exit_fast_discard = True
                            logger.warning(f"🏛️ [FAST_DISCARD] {symbol} stagnant at {pnl_pct:+.2f}% after 10m. Releasing slot.")
                    except: pass
                
                # Optional: Claude analysis for exit decision
                should_exit_claude = False
                if self.news_fetcher.use_claude and pnl_pct > 0.3:
                    try:
                        # Call Claude to analyze if we should exit this profitable position
                        logger.info(f"[CLAUDE] Analyzing exit for {symbol} (+{pnl_pct:.2f}%)")
                        
                        # Fetch recent news for exit decision
                        news = self.news_fetcher._fetch_raw_news(symbol)
                        if news:
                            # Ask Claude: should we exit now or hold for more?
                            analysis = self.news_fetcher.claude.analyze_news_batch(symbol, news[:5])
                            sentiment = analysis.get('sentiment', 'NEUTRAL')
                            confidence = analysis.get('confidence', 0.5)
                            
                            # Exit if sentiment turns against our position
                            if direction == 'LONG' and sentiment == 'BEARISH' and confidence > 0.7:
                                should_exit_claude = True
                                logger.info(f"[CLAUDE_EXIT] {symbol} LONG exit - bearish sentiment detected (conf: {confidence:.2f})")
                            elif direction == 'SHORT' and sentiment == 'BULLISH' and confidence > 0.7:
                                should_exit_claude = True
                                logger.info(f"[CLAUDE_EXIT] {symbol} SHORT exit - bullish sentiment detected (conf: {confidence:.2f})")
                            else:
                                logger.info(f"[CLAUDE_HOLD] {symbol} sentiment: {sentiment} (conf: {confidence:.2f}) - holding")
                        else:
                            # No news available - use aggressive profit taking
                            if pnl_pct > 0.8:
                                should_exit_claude = True
                                logger.info(f"[CLAUDE_EXIT] {symbol} profit {pnl_pct:.2f}% exceeds threshold (no news)")
                    except Exception as e:
                        logger.warning(f"[CLAUDE] Exit analysis failed: {e}")
                
                # Exit if any condition is met
                if hit_sl or hit_tp or hit_profit_sniper or should_exit_time or should_exit_fast_discard or should_exit_claude:
                    # Build detailed close reason
                    if hit_sl:
                        reason = f"Stop Loss hit at ${current_price:.2f} (SL: ${stop_loss:.2f} Mark, PnL: {pnl_pct:+.2f}%)"
                    elif hit_tp:
                        reason = f"Take Profit hit at ${current_price:.2f} (TP: ${take_profit:.2f}, PnL: {pnl_pct:+.2f}%)"
                    elif hit_profit_sniper:
                        reason = f"V13.9 Sniper Profit 0.5% (PnL: {pnl_pct:+.2f}%, Entry: ${entry_price:.2f})"
                    elif should_exit_fast_discard:
                        duration_min = time_open_minutes if 'time_open_minutes' in locals() else 0
                        reason = f"Fast Discard after {duration_min:.0f}min (PnL: {pnl_pct:+.2f}%, no momentum)"
                    elif should_exit_time:
                        duration_h = time_open_hours if 'time_open_hours' in locals() else 0
                        asset_class_name = pos.get('asset_class', 'crypto')
                        reason = f"Time Exit {asset_class_name} after {duration_h*60:.0f}min (PnL: {pnl_pct:+.2f}%)"
                    else:
                        reason = f"Claude AI Exit (sentiment changed, PnL: {pnl_pct:+.2f}%)"
                    
                    logger.warning(f"[ALERT] EXIT: {symbol} - {reason}")
                    
                    self._close_position(symbol, pos, reason)
                    del positions[symbol]
                else:
                    logger.info(f"[HOLD] {symbol} | PnL: {pnl_pct:+.2f}% | Time: {entry_time_str[:16] if entry_time_str else 'N/A'}")

            except Exception as e: logger.error(f"[ERROR] Manage failed for {symbol}: {e}")

    def _safe_fetch_rsi_volume(self, symbol: str) -> Optional[Dict]:
        """Helper for parallel fetch of RSI and Volume (Double Alpha) with Strict Sanitization (V14.1)"""
        try:
            # 1. Fetch OHLCV (Limit 50 for speed)
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe='1h', limit=50)
            if not ohlcv or len(ohlcv) < 20: return None
            
            # 2. Get Volume (24h) & RSI with Zero-Tolerance Sanitization
            try:
                # Use mean volume of last 24 candles as a robust proxy for 24h volume/liquidity
                df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
                
                # Strict Type Conversion
                df['close'] = pd.to_numeric(df['close'], errors='coerce')
                df['volume'] = pd.to_numeric(df['volume'], errors='coerce')
                
                # Check for empty or invalid data (NaNs)
                if df['close'].isnull().any() or df['volume'].isnull().any():
                     # logger.warning(f"[SKIP] {symbol}: Corrupt OHLCV data found (NaNs).")
                     return None
                
                rsi_series = calculate_rsi(df['close'], period=14)
                
                # Validation: RSI must be a valid float
                rsi_val = rsi_series.iloc[-1]
                if pd.isna(rsi_val): return None
                rsi = float(rsi_val)
                
                # Validation: Volume must be valid
                vol_val = df['volume'].iloc[-24:].sum()
                if pd.isna(vol_val) or vol_val <= 0: return None
                volume = float(vol_val)
                
                # Validation: Price must be valid
                price_val = df['close'].iloc[-1]
                if pd.isna(price_val) or price_val <= 0: return None
                price = float(price_val)
                
                return {
                    'symbol': symbol,
                    'rsi': rsi,
                    'volume': volume,
                    'price': price
                }
            except Exception as e:
                # logger.debug(f"[calc_error] {symbol}: {e}")
                return None
                
        except Exception as e:
            # logger.debug(f"Failed to fetch {symbol}: {e}")
            return None

    def scan_market_double_alpha(self) -> List[str]:
        """
        🏛️ EMPIRE V14.0: DOUBLE ALPHA SELECTION
        1. Fetch all 415+ Futures (Dynamic API Call)
        2. Short Hunter: Top 20 (RSI Desc -> Top 50 -> Vol Desc)
        3. Long Sniper: Top 20 (RSI Asc -> Top 50 -> Vol Desc)
        4. Merge & Return
        """
        logger.info(f"\n{'='*70}\n[INFO] STARTING DOUBLE ALPHA SCAN (V14.0)\n{'='*70}")
        
        # 1. Fetch All Symbols (Dynamic List from Binance API)
        # Using the new robust method to avoid MATIC/POL issues
        try:
            all_symbols = self.exchange.get_all_futures_symbols()
        except Exception as e:
            logger.error(f"[SCAN_CRITICAL] Failed to get symbols: {e}")
            all_symbols = []
            
        if not all_symbols:
             logger.warning("[SCAN] Zero candidates found! Falling back to configured assets.")
             return list(TradingConfig.EMPIRE_ASSETS.keys())

        logger.info(f"[SCAN] Found {len(all_symbols)} active USDT perpetuals. Fetching data...")
        
        candidates = []
        # Parallel fetch for speed (LIMIT 50 workers)
        with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
            future_to_symbol = {executor.submit(self._safe_fetch_rsi_volume, sym): sym for sym in all_symbols}
            
            for future in concurrent.futures.as_completed(future_to_symbol):
                res = future.result()
                if res and res['volume'] > 0: # Basic filter
                    candidates.append(res)
        
        logger.info(f"[SCAN] Successfully analyzed {len(candidates)} assets.")
        
        if not candidates:
            return list(TradingConfig.EMPIRE_ASSETS.keys())

        # 2. Double Alpha Logic
        
        # A. Short Hunter (RSI Descending)
        # Sort by RSI DESC (High RSI first)
        sorted_rsi_desc = sorted(candidates, key=lambda x: x['rsi'], reverse=True)
        # Take Top 50
        short_pool = sorted_rsi_desc[:50]
        # Sort these 50 by Volume DESC (Big Volume first)
        short_final = sorted(short_pool, key=lambda x: x['volume'], reverse=True)[:20]
        
        # B. Long Sniper (RSI Ascending)
        # Sort by RSI ASC (Low RSI first)
        sorted_rsi_asc = sorted(candidates, key=lambda x: x['rsi'], reverse=False)
        # Take Top 50
        long_pool = sorted_rsi_asc[:50]
        # Sort these 50 by Volume DESC (Big Volume first)
        long_final = sorted(long_pool, key=lambda x: x['volume'], reverse=True)[:20]
        
        # 3. Merge Lists
        final_set = set()
        
        logger.info(f"\n--- SHORT HUNTER (Top 20) ---")
        for i, c in enumerate(short_final):
            logger.info(f"#{i+1:02d} SHORT: {c['symbol']:<15} | RSI: {c['rsi']:>5.1f} | Vol: {c['volume']:,.0f}")
            final_set.add(c['symbol'])
            
        logger.info(f"\n--- LONG SNIPER (Top 20) ---")
        for i, c in enumerate(long_final):
            logger.info(f"#{i+1:02d} LONG : {c['symbol']:<15} | RSI: {c['rsi']:>5.1f} | Vol: {c['volume']:,.0f}")
            final_set.add(c['symbol'])
            
        # Return unique symbols list
        final_list = list(final_set)
        logger.info(f"[SCAN] Final Selection: {len(final_list)} assets sent to Analysis Engine.")
        return final_list

# ==================== LAMBDA HANDLER ====================

def lambda_handler(event, context):
    try:
        engine = TradingEngine()
        
        # 🏛️ EMPIRE V14.0: DOUBLE ALPHA SELECTION
        # Use event['symbols'] for manual override, otherwise run the scan
        if event.get('symbols'):
             symbols_str = event.get('symbols')
             symbols = [s.strip() for s in symbols_str.split(',') if s.strip()]
             logger.info(f"[INFO] Manual symbol override: {len(symbols)} assets")
        else:
             # Run the full V14.0 scan
             symbols = engine.scan_market_double_alpha()
        
        logger.info(f"[INFO] Processing {len(symbols)} symbols: {', '.join(symbols)}")
        
        risk_state = engine.persistence.load_risk_state()
        today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
        if risk_state.get('last_reset_date') != today:
            logger.info(f"[INFO] New day reset {today}")
            engine.risk_manager.reset_daily()
            new_state = engine.risk_manager.get_state()
            new_state['last_reset_date'] = today
            engine.persistence.save_risk_state(new_state)

        # 🏛️ EMPIRE V13.5: Fetch BTC RSI for the Bedrock Matrix Filter
        btc_rsi = None
        try:
            # We use the smart cache to avoid wasting time/latency
            btc_ohlcv = engine._get_ohlcv_smart('BTC/USDT:USDT', '1h')
            # Fix: classify_asset identifies BTC/USDT:USDT as crypto
            btc_ta = analyze_market(btc_ohlcv, symbol='BTC/USDT:USDT', asset_class=AssetClass.CRYPTO)
            btc_rsi = btc_ta.get('rsi')
            logger.info(f"[BEDROCK] BTC Context: RSI={btc_rsi:.1f}")
        except Exception as e:
            logger.warning(f"[BEDROCK] Failed to fetch BTC RSI context: {e}")

        results = []
        for s in symbols:
            try:
                res = engine.run_cycle(s, btc_rsi=btc_rsi)
                results.append(res)
            except Exception as e:
                logger.error(f"[ERROR] Cycle failed for {s}: {e}")
                results.append({'symbol': s, 'status': 'CYCLE_ERROR', 'error': str(e)})
        
        logger.info(f"[INFO] Scan complete: {len(results)} results")
        return {'statusCode': 200, 'body': json.dumps({'status': 'SUCCESS', 'results': results})}
    except Exception as e:
        logger.error(f"[CRITICAL] Global failure: {e}")
        return {'statusCode': 500, 'body': json.dumps({'status': 'ERROR', 'error': str(e)})}
