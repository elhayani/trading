from numpy._core.records import *
from numpy._core.records import __all__, __doc__
