"""
🔌 Lambda Scanner WebSocket - Empire V16.2
===========================================
Scanner utilisant WebSocket Binance (remplace REST API)
Latence: 50ms vs 800ms REST
Performance: 16x plus rapide
"""

import json
import os
import time
import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional

from websocket_manager import BinanceWebSocketManager
from market_analysis import MarketAnalyzer
from decision_engine import DecisionEngine
from risk_manager import RiskManager
from trading_engine import TradingEngine
from config import TradingConfig

logger = logging.getLogger(__name__)

class WebSocketScanner:
    """Scanner WebSocket pour trading momentum"""
    
    def __init__(self):
        self.ws_manager = BinanceWebSocketManager(demo_mode=not TradingConfig.LIVE_MODE)
        self.market_analyzer = MarketAnalyzer()
        self.decision_engine = DecisionEngine(RiskManager())
        self.trading_engine = TradingEngine()
        
        # Symboles à surveiller
        self.symbols = self._get_trading_symbols()
        self.momentum_scores = {}
        self.processed_symbols = set()
        
        # Stats
        self.messages_processed = 0
        self.signals_detected = 0
        self.trades_executed = 0
        
    def _get_trading_symbols(self) -> List[str]:
        """Récupération symboles pour trading"""
        # Symboles principaux pour POC
        return [
            'BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT',
            'AVAXUSDT', 'LINKUSDT', 'DOGEUSDT', 'ADAUSDT', 'DOTUSDT',
            'PEPEUSDT', 'SHIBUSDT', 'MATICUSDT', 'UNIUSDT', 'ATOMUSDT'
        ]
    
    async def scan_with_websocket(self, context) -> Dict:
        """Scanner principal utilisant WebSocket"""
        start_time = time.time()
        
        try:
            logger.info(f"[WS_SCANNER_START] Scanning {len(self.symbols)} symbols")
            
            # Connexion WebSocket klines 1min
            streams = [f"{symbol.lower()}@kline_1m" for symbol in self.symbols]
            
            if not await self.ws_manager.connect(streams):
                return {
                    'status': 'ERROR',
                    'reason': 'WebSocket connection failed',
                    'duration': time.time() - start_time
                }
            
            # Timeout Lambda (15 minutes max - 30s marge)
            timeout = (context.get_remaining_time_in_millis() - 30000) / 1000
            
            # Boucle scanning
            while time.time() - start_time < timeout:
                # Récupération kline
                kline_data = await self.ws_manager.get_next_kline()
                
                if kline_data:
                    await self._process_kline(kline_data)
                    self.messages_processed += 1
                
                # Stats toutes les 30 secondes
                if int(time.time()) % 30 == 0:
                    await self._log_stats()
            
            # Finalisation
            results = await self._finalize_scan()
            
            return {
                'status': 'SUCCESS',
                'duration': time.time() - start_time,
                'messages_processed': self.messages_processed,
                'signals_detected': self.signals_detected,
                'trades_executed': self.trades_executed,
                'results': results
            }
            
        except Exception as e:
            logger.error(f"[WS_SCANNER_ERROR] {e}")
            return {
                'status': 'ERROR',
                'reason': str(e),
                'duration': time.time() - start_time
            }
        
        finally:
            await self.ws_manager.close()
    
    async def _process_kline(self, kline_data: Dict):
        """Traitement kline WebSocket"""
        try:
            symbol = kline_data['symbol']
            
            # Éviter doublons
            if symbol in self.processed_symbols:
                return
            
            # Analyse momentum
            momentum_score = await self._calculate_momentum_score(kline_data)
            self.momentum_scores[symbol] = momentum_score
            
            # Signal détecté?
            if momentum_score >= TradingConfig.MIN_MOMENTUM_SCORE:
                self.signals_detected += 1
                await self._handle_signal(symbol, kline_data, momentum_score)
            
            self.processed_symbols.add(symbol)
            
        except Exception as e:
            logger.error(f"[WS_KLINE_ERROR] {e}")
    
    async def _calculate_momentum_score(self, kline_data: Dict) -> float:
        """Calcul score momentum WebSocket"""
        try:
            symbol = kline_data['symbol']
            ohlc = {
                'open': kline_data['open'],
                'high': kline_data['high'],
                'low': kline_data['low'],
                'close': kline_data['close'],
                'volume': kline_data['volume']
            }
            
            # Analyse marché
            analysis = await self.market_analyzer.analyze_symbol(symbol, ohlc)
            
            # Score momentum basé sur:
            # 1. Mouvement prix (0-40 points)
            price_move = self._calculate_price_momentum(ohlc)
            
            # 2. Volume surge (0-30 points)
            volume_score = self._calculate_volume_score(ohlc)
            
            # 3. EMA crossover (0-30 points)
            ema_score = analysis.get('ema_score', 0)
            
            total_score = price_move + volume_score + ema_score
            
            return min(100, total_score)
            
        except Exception as e:
            logger.error(f"[WS_MOMENTUM_ERROR] {e}")
            return 0.0
    
    def _calculate_price_momentum(self, ohlc: Dict) -> float:
        """Calcul momentum prix"""
        try:
            open_price = ohlc['open']
            close_price = ohlc['close']
            high_price = ohlc['high']
            low_price = ohlc['low']
            
            # Mouvement prix en %
            price_change = abs(close_price - open_price) / open_price
            
            # Range (volatilité)
            range_pct = (high_price - low_price) / open_price
            
            # Score basé sur mouvement et range
            momentum = (price_change * 2000) + (range_pct * 1000)
            
            return min(40, momentum)
            
        except Exception:
            return 0.0
    
    def _calculate_volume_score(self, ohlc: Dict) -> float:
        """Calcul score volume"""
        try:
            volume = ohlc['volume']
            
            # Score basé sur volume (simplifié)
            # En réalité: comparer à moyenne volume
            if volume > 1000000:  # > 1M
                return 30
            elif volume > 500000:  # > 500K
                return 20
            elif volume > 100000:  # > 100K
                return 10
            else:
                return 5
                
        except Exception:
            return 0.0
    
    async def _handle_signal(self, symbol: str, kline_data: Dict, score: float):
        """Traitement signal de trading"""
        try:
            logger.info(f"[WS_SIGNAL] {symbol}: Score {score:.1f}")
            
            # Contexte pour décision
            context = {
                'symbol': symbol,
                'price': kline_data['close'],
                'volume': kline_data['volume'],
                'timestamp': kline_data['timestamp'],
                'score': score
            }
            
            # Analyse technique
            ta_result = {
                'price': kline_data['close'],
                'volume': kline_data['volume'],
                'atr': self._estimate_atr(kline_data),
                'score': score,
                'momentum': 'BULLISH' if kline_data['close'] > kline_data['open'] else 'BEARISH'
            }
            
            # Décision trading
            decision = self.decision_engine.evaluate_with_risk(
                context=context,
                ta_result=ta_result,
                symbol=symbol,
                capital=10000,  # Capital par défaut
                direction='LONG' if kline_data['close'] > kline_data['open'] else 'SHORT'
            )
            
            # Exécution si signal validé
            if decision.get('proceed', False):
                await self._execute_trade(symbol, decision, kline_data)
            
        except Exception as e:
            logger.error(f"[WS_SIGNAL_ERROR] {symbol}: {e}")
    
    def _estimate_atr(self, kline_data: Dict) -> float:
        """Estimation ATR (simplifiée)"""
        try:
            high = kline_data['high']
            low = kline_data['low']
            close = kline_data['close']
            
            # True Range
            tr = max(high - low, abs(high - close), abs(low - close))
            
            # ATR estimé (en réalité utiliser 14 périodes)
            return tr * 0.01  # 1% du prix comme approximation
            
        except Exception:
            return 0.01
    
    async def _execute_trade(self, symbol: str, decision: Dict, kline_data: Dict):
        """Exécution trade via WebSocket"""
        try:
            quantity = decision.get('quantity', 0)
            side = decision.get('side', 'LONG')
            
            if quantity <= 0:
                return
            
            # Exécution via trading engine
            result = await self.trading_engine.execute_trade_websocket(
                symbol=symbol,
                side=side,
                quantity=quantity,
                price=kline_data['close']
            )
            
            if result:
                self.trades_executed += 1
                logger.info(f"[WS_EXECUTION] {symbol}: {side} {quantity} @ {kline_data['close']}")
            
        except Exception as e:
            logger.error(f"[WS_EXECUTION_ERROR] {symbol}: {e}")
    
    async def _log_stats(self):
        """Logs statistiques"""
        try:
            logger.info(f"[WS_STATS] Messages: {self.messages_processed}, "
                       f"Signals: {self.signals_detected}, "
                       f"Trades: {self.trades_executed}")
            
            # Stats WebSocket
            ws_stats = self.ws_manager.get_stats()
            logger.info(f"[WS_CONNECTION] Connected: {ws_stats['connected']}, "
                       f"Buffer: {ws_stats['buffer_size']}")
            
        except Exception as e:
            logger.error(f"[WS_STATS_ERROR] {e}")
    
    async def _finalize_scan(self) -> Dict:
        """Finalisation scan"""
        try:
            # Top 5 symboles par score
            top_symbols = sorted(
                self.momentum_scores.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]
            
            return {
                'total_symbols': len(self.symbols),
                'processed_symbols': len(self.processed_symbols),
                'top_symbols': top_symbols,
                'avg_score': sum(self.momentum_scores.values()) / len(self.momentum_scores) if self.momentum_scores else 0,
                'websocket_stats': self.ws_manager.get_stats()
            }
            
        except Exception as e:
            logger.error(f"[WS_FINALIZE_ERROR] {e}")
            return {}

# Lambda handler
async def lambda_handler(event, context):
    """Lambda handler WebSocket Scanner"""
    
    # Configuration logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    logger.info(f"[WS_LAMBDA_START] Scanner WebSocket V16.2")
    
    try:
        # Création scanner
        scanner = WebSocketScanner()
        
        # Lancement scan
        result = await scanner.scan_with_websocket(context)
        
        # Log final
        logger.info(f"[WS_LAMBDA_END] Status: {result.get('status')}, "
                   f"Duration: {result.get('duration', 0):.2f}s")
        
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
        
    except Exception as e:
        logger.error(f"[WS_LAMBDA_ERROR] {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'status': 'ERROR',
                'reason': str(e)
            })
        }

# Handler synchrone pour AWS Lambda
def lambda_handler_sync(event, context):
    """Handler synchrone compatible AWS Lambda"""
    return asyncio.run(lambda_handler(event, context))
